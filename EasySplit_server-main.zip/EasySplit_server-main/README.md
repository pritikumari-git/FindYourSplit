### This is the server side of EasySplit and the client side link is below

https://github.com/iamkartiksingh-K/EasySplit_client
